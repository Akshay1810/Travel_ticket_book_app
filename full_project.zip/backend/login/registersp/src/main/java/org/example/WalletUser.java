//package org.example;
//
//import java.util.Set;
//
//import org.hyperledger.fabric.sdk.Enrollment;
//import org.hyperledger.fabric.sdk.User;
//
////public class WalletUser implements User {
//
//	@Override
//	public String getName() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Set<String> getRoles() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public String getAccount() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public String getAffiliation() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Enrollment getEnrollment() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public String getMspId() {
//		// TODO Auto-generated method stub
//		return null;
//	}}
////    private final String name;
////    private final String mspId;
////    private final Enrollment enrollment;
////    private final String affiliation;
////
////    public WalletUser(String name, String mspId, Enrollment enrollment, String affiliation) {
////        this.name = name;
////        this.mspId = mspId;
////        this.enrollment = enrollment;
////        this.affiliation = affiliation;
////    }
////
////    @Override
////    public String getName() { return name; }
////
////    @Override
////    public Set<String> getRoles() { return null; }
////
////    @Override
////    public String getAccount() { return null; }
////
////    @Override
////    public String getAffiliation() { return affiliation; }
////
////    @Override
////    public Enrollment getEnrollment() { return enrollment; }
////
////    @Override
////    public String getMspId() { return mspId; }
////}
