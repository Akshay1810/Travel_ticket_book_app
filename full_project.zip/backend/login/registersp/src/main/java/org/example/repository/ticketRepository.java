package org.example.repository;

import java.util.List;

import org.example.entity.ticket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ticketRepository extends JpaRepository<ticket, String> {
	
	List<ticket> findAllByCustomerIdAndIsCancelledFalse( String email);
	
	List<ticket> findByBookingBlockLessThanAndIsConfirmedFalse(int bookingBlock);
	
//    Optional<userCustomer> findByEmail(String email); // To fetch user by email
}
